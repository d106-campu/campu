-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: k10d106.p.ssafy.io    Database: d106
-- ------------------------------------------------------
-- Server version	5.5.5-10.11.7-MariaDB-1:10.11.7+maria~ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `campsite_original`
--

DROP TABLE IF EXISTS `campsite_original`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `campsite_original` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '식별번호',
  `content_id` varchar(128) DEFAULT NULL COMMENT '콘텐츠 아이디',
  `faclt_nm` varchar(128) DEFAULT NULL COMMENT '야영장명',
  `line_intro` varchar(512) DEFAULT NULL COMMENT '한줄소개',
  `intro` varchar(2048) DEFAULT NULL COMMENT '소개',
  `allar` int(11) DEFAULT NULL COMMENT '전체면적 (단위: ㎡)',
  `insrnc_at` char(1) DEFAULT NULL COMMENT '영업배상책임보험 가입여부 (Y: 사용, N: 미사용)',
  `trsagnt_no` varchar(32) DEFAULT NULL COMMENT '관광사업자번호',
  `bizrno` varchar(32) DEFAULT NULL COMMENT '사업자번호',
  `faclt_div_nm` varchar(16) DEFAULT NULL COMMENT '사업주체 구분',
  `mange_div_nm` varchar(16) DEFAULT NULL COMMENT '운영주체 (직영, 위탁)',
  `mgc_div` varchar(128) DEFAULT NULL COMMENT '운영기관',
  `manage_sttus` varchar(16) DEFAULT NULL COMMENT '운영상태',
  `hvof_bgnde` datetime DEFAULT NULL COMMENT '휴장기간 시작일',
  `hvof_enddle` datetime DEFAULT NULL COMMENT '휴장기간 종료일',
  `feature_nm` varchar(512) DEFAULT NULL COMMENT '특징',
  `induty` varchar(128) DEFAULT NULL COMMENT '업종',
  `lct_cl` varchar(128) DEFAULT NULL COMMENT '입지구분',
  `do_nm` varchar(32) DEFAULT NULL COMMENT '도',
  `sigungu_nm` varchar(64) DEFAULT NULL COMMENT '시군구',
  `zipcode` varchar(128) DEFAULT NULL COMMENT '우편번호',
  `addr1` varchar(512) DEFAULT NULL COMMENT '주소',
  `addr2` varchar(512) DEFAULT NULL COMMENT '주소상세',
  `map_x` double DEFAULT NULL COMMENT '경도 (X)',
  `map_y` double DEFAULT NULL COMMENT '위도 (Y)',
  `direction` varchar(1024) DEFAULT NULL COMMENT '오시는 길 컨텐츠',
  `tel` char(11) DEFAULT NULL COMMENT '전화',
  `homepage` varchar(1024) DEFAULT NULL COMMENT '홈페이지',
  `resve_url` varchar(1024) DEFAULT NULL COMMENT '예약 페이지',
  `resve_cl` varchar(64) DEFAULT NULL COMMENT '예약 구분',
  `manage_nmpr` int(11) DEFAULT NULL COMMENT '상주관리인원',
  `gnrl_site_co` int(11) DEFAULT NULL COMMENT '주요시설 일반야영장',
  `auto_site_co` int(11) DEFAULT NULL COMMENT '주요시설 자동차야영장',
  `glamp_site_co` int(11) DEFAULT NULL COMMENT '주요시설 글램핑',
  `carav_site_co` int(11) DEFAULT NULL COMMENT '주요시설 카라반',
  `indvdl_carav_site_co` int(11) DEFAULT NULL COMMENT '주요시설 개인 카라반',
  `sited_stnc` int(11) DEFAULT NULL COMMENT '사이트간 거리',
  `site_mg1_width` int(11) DEFAULT NULL COMMENT '사이트 크기1 가로 (단위: m)',
  `site_mg2_width` int(11) DEFAULT NULL COMMENT '사이트 크기2 가로 (단위: m)',
  `site_mg3_width` int(11) DEFAULT NULL COMMENT '사이트 크기3 가로 (단위: m)',
  `site_mg1_vrticl` int(11) DEFAULT NULL COMMENT '사이트 크기1 세로 (단위: m)',
  `site_mg2_vrticl` int(11) DEFAULT NULL COMMENT '사이트 크기2 세로 (단위: m)',
  `site_mg3_vrticl` int(11) DEFAULT NULL COMMENT '사이트 크기3 세로 (단위: m)',
  `site_mg1_co` int(11) DEFAULT NULL COMMENT '사이트 크기1 수량 (단위: 개)',
  `site_mg2_co` int(11) DEFAULT NULL COMMENT '사이트 크기2 수량 (단위: 개)',
  `site_mg3_co` int(11) DEFAULT NULL COMMENT '사이트 크기3 수량 (단위: 개)',
  `site_bottom_cl1` int(11) DEFAULT NULL COMMENT '잔디',
  `site_bottom_cl2` int(11) DEFAULT NULL COMMENT '파쇄석',
  `site_bottom_cl3` int(11) DEFAULT NULL COMMENT '테크',
  `site_bottom_cl4` int(11) DEFAULT NULL COMMENT '자갈',
  `site_bottom_cl5` int(11) DEFAULT NULL COMMENT '맨흙',
  `tooltip` varchar(1024) DEFAULT NULL COMMENT '툴팁',
  `glamp_inner_fclty` varchar(512) DEFAULT NULL COMMENT '글램핑 내부시설',
  `carav_inner_fclty` varchar(512) DEFAULT NULL COMMENT '카라반 내부시설',
  `prmisn_de` date DEFAULT NULL COMMENT '인허가일자',
  `oper_pd_cl` varchar(32) DEFAULT NULL COMMENT '운영기간',
  `oper_de_cl` varchar(32) DEFAULT NULL COMMENT '운영일',
  `trler_acmpny_at` char(1) DEFAULT NULL COMMENT '개인 트레일러 동반 여부 (Y: 사용, N: 미사용)',
  `carav_acmpny_at` char(1) DEFAULT NULL COMMENT '개인 카라반 동반 여부 (Y: 사용, N: 미사용)',
  `toilet_co` int(11) DEFAULT NULL COMMENT '화장실 개수 (단위: 개)',
  `swrm_co` int(11) DEFAULT NULL COMMENT '샤워실 개수 (단위: 개)',
  `wtrpl_co` int(11) DEFAULT NULL COMMENT '개수대 개수 (단위: 개)',
  `brazier_cl` varchar(16) DEFAULT NULL COMMENT '화로대',
  `sbrs_cl` varchar(256) DEFAULT NULL COMMENT '부대시설',
  `sbrs_etc` varchar(256) DEFAULT NULL COMMENT '부대시설 기타',
  `posbl_fclty_cl` varchar(256) DEFAULT NULL COMMENT '주변이용가능시설',
  `posbl_fclty_etc` varchar(256) DEFAULT NULL COMMENT '주변이용가능시설 기타',
  `cltur_event_at` char(1) DEFAULT NULL COMMENT '자체문화행사 여부 (Y: 사용, N: 미사용)',
  `cltur_event` varchar(128) DEFAULT NULL COMMENT '자체문화행사명',
  `exprn_progrm_at` char(1) DEFAULT NULL COMMENT '체험프로그램 여부 (Y: 사용, N: 미사용)',
  `exprn_progrm` varchar(128) DEFAULT NULL COMMENT '체험프로그램명',
  `extshr_co` int(11) DEFAULT NULL COMMENT '소화기 개수 (단위: 개)',
  `frprvt_wrpp_co` int(11) DEFAULT NULL COMMENT '방화수 개수 (단위: 개)',
  `frprvt_sand_co` int(11) DEFAULT NULL COMMENT '방화사 개수 (단위: 개)',
  `fire_sensor_co` int(11) DEFAULT NULL COMMENT '화재감지기 개수',
  `thema_envrn_cl` varchar(128) DEFAULT NULL COMMENT '테마환경',
  `eqpmn_lend_cl` varchar(128) DEFAULT NULL COMMENT '캠핑장비대여',
  `animal_cmg_cl` varchar(16) DEFAULT NULL COMMENT '애완동물출입',
  `tour_era_cl` varchar(32) DEFAULT NULL COMMENT '여행시기',
  `first_image_url` varchar(1024) DEFAULT NULL COMMENT '대표이미지',
  `createdtime` datetime DEFAULT NULL COMMENT '등록일',
  `modifiedtime` datetime DEFAULT NULL COMMENT '수정일',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='캠핑장 원본';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campsite_original`
--

LOCK TABLES `campsite_original` WRITE;
/*!40000 ALTER TABLE `campsite_original` DISABLE KEYS */;
/*!40000 ALTER TABLE `campsite_original` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-20  9:51:21
