-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: k10d106.p.ssafy.io    Database: d106
-- ------------------------------------------------------
-- Server version	5.5.5-10.11.7-MariaDB-1:10.11.7+maria~ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '식별번호',
  `role` varchar(16) NOT NULL COMMENT '권한',
  `account` varchar(16) NOT NULL COMMENT '아이디',
  `password` varchar(72) NOT NULL COMMENT '비밀번호',
  `nickname` varchar(8) NOT NULL COMMENT '닉네임',
  `gender` char(1) DEFAULT NULL COMMENT '성별',
  `birth_year` char(4) DEFAULT NULL COMMENT '출생년도',
  `profile_image_url` varchar(1024) DEFAULT NULL COMMENT '프로필 이미지 주소',
  `tel` char(11) NOT NULL COMMENT '전화번호',
  `delete_time` datetime DEFAULT NULL COMMENT '회원탈퇴 시간',
  `create_time` datetime DEFAULT current_timestamp() COMMENT '회원가입 시간',
  `update_time` datetime DEFAULT NULL COMMENT '정보수정 시간',
  PRIMARY KEY (`id`),
  UNIQUE KEY `account` (`account`),
  UNIQUE KEY `nickname` (`nickname`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='회원';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'USER','hoing97s','$2a$10$uDjXQSDlHCWIXkO4SzfY7OVgs1aPBedacmj/8wHt1SjahOcEOY08y','준호짱맨','M','2000','https://avatars.githubusercontent.com/u/140311409','00000000000',NULL,'2024-05-16 10:28:09','2024-05-18 16:29:32'),(2,'USER','danbeeS2','$2a$10$uDjXQSDlHCWIXkO4SzfY7OVgs1aPBedacmj/8wHt1SjahOcEOY08y','단비꺼야','F','2000','https://avatars.githubusercontent.com/u/120550679','00000000000',NULL,'2024-05-16 10:28:09','2024-05-18 16:33:37'),(3,'USER','cheesecat47','$2a$10$uDjXQSDlHCWIXkO4SzfY7OVgs1aPBedacmj/8wHt1SjahOcEOY08y','불꽃두목주용','M','2000','https://avatars.githubusercontent.com/u/41780495','00000000000',NULL,'2024-05-16 10:28:09','2024-05-18 16:42:03'),(4,'USER','rnlgus7660','$2a$10$wIin/akMjtLEc2WoefVPaemNP2nsGhEF3aDBltC2Z8RJXK9PBvSW6','커현공듀님','M','2000','https://avatars.githubusercontent.com/u/139833245','00000000001',NULL,'2024-05-16 10:28:09','2024-05-19 19:02:47'),(5,'USER','minnnnnk0','$2a$10$uDjXQSDlHCWIXkO4SzfY7OVgs1aPBedacmj/8wHt1SjahOcEOY08y','minnnnnk','F','2000','https://avatars.githubusercontent.com/u/139419164','00000000000',NULL,'2024-05-16 10:28:09',NULL),(6,'USER','choihojo','$2a$10$uDjXQSDlHCWIXkO4SzfY7OVgs1aPBedacmj/8wHt1SjahOcEOY08y','choihojo','M','2000','https://avatars.githubusercontent.com/u/87483951?','00000000000',NULL,'2024-05-16 10:28:09',NULL),(7,'OWNER','sajangnim','$2a$10$uDjXQSDlHCWIXkO4SzfY7OVgs1aPBedacmj/8wHt1SjahOcEOY08y','최사장','F','2000','https://avatars.githubusercontent.com/u/139419164','00000000000',NULL,'2024-05-16 10:28:09',NULL),(8,'OWNER','sajangnim2','$2a$10$uDjXQSDlHCWIXkO4SzfY7OVgs1aPBedacmj/8wHt1SjahOcEOY08y','최호조','F','2000','https://avatars.githubusercontent.com/u/87483951?','00000000000',NULL,'2024-05-16 10:28:09',NULL),(9,'USER','testd106','$2a$12$5z6Bhj5BYHSw5XgYcFkwcu.p1GDdv/gHSTKr67LpdkJTqghM39LMe','test계정1','F','2000','https://k10d106.p.ssafy.io/api/file/user/8/profile/a18dd83d-e548-48d5-be38-e1b32271dbca_test.png','00000000005',NULL,'2024-05-16 10:28:09',NULL),(10,'USER','siyeon','$2a$10$uDjXQSDlHCWIXkO4SzfY7OVgs1aPBedacmj/8wHt1SjahOcEOY08y','시연','F','2024','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQZOmckN3Rd0PDEV7j5ne8LC3tHuA9KNFfQOw&s','01029775868',NULL,'2024-05-16 10:28:09',NULL),(11,'USER','danbxx','$2a$10$1qNwqisSwTk66legpWSLJO/hzq82/EbIwRk8CfbcZuNN9.CDfniYy','단비꺼야아아',NULL,NULL,'https://k10d106.p.ssafy.io/api/file/user/11/profile/a2388db7-ecb0-4ba8-8201-bdc1324b30ef_요구르트_fastest.gif','01085133964',NULL,'2024-05-18 17:31:33','2024-05-19 04:22:41'),(12,'USER','minnk0','$2a$10$/9YLyv74aFlHovbtl1XHb.DMfH9vLq0iTUPPkYX4eVxBjXYEZ8kba','프린스최',NULL,NULL,NULL,'01062920069',NULL,'2024-05-19 16:49:13','2024-05-19 16:49:13'),(13,'USER','rnlgus1234','$2a$10$0dhwdIBPEd0477bRNcxbXeqLm7o7NFRLz/KHwX5IXgh3u5deywZO2','진짜응애귀현',NULL,NULL,'https://k10d106.p.ssafy.io/api/file/user/13/profile/bdb30ceb-8768-4f12-a88e-f7064ca44582_cat.jpg','01088737660',NULL,'2024-05-19 19:04:03','2024-05-19 19:28:55');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-20  9:51:25
