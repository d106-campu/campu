-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: k10d106.p.ssafy.io    Database: d106
-- ------------------------------------------------------
-- Server version	5.5.5-10.11.7-MariaDB-1:10.11.7+maria~ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '식별번호',
  `campsite_id` bigint(20) NOT NULL COMMENT '캠핑장 식별번호',
  `reservation_id` bigint(20) NOT NULL COMMENT '예약 식별번호',
  `score` int(11) NOT NULL COMMENT '리뷰 점수',
  `content` varchar(200) NOT NULL COMMENT '리뷰 내용',
  `create_time` datetime DEFAULT current_timestamp() COMMENT '생성 시간',
  `update_time` datetime DEFAULT NULL COMMENT '수정 시간',
  PRIMARY KEY (`id`),
  KEY `review_campsite_FK` (`campsite_id`),
  KEY `review_reservation_FK` (`reservation_id`),
  CONSTRAINT `review_campsite_FK` FOREIGN KEY (`campsite_id`) REFERENCES `campsite` (`id`),
  CONSTRAINT `review_reservation_FK` FOREIGN KEY (`reservation_id`) REFERENCES `reservation` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='캠핑장 리뷰';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
INSERT INTO `review` VALUES (7,100075,27,5,'review','2024-05-18 15:19:40',NULL),(8,100075,28,4,'review','2024-05-18 15:19:40',NULL),(9,100075,29,3,'review','2024-05-18 15:19:40',NULL),(10,100075,30,5,'review','2024-05-18 15:19:40',NULL),(11,100075,31,4,'review','2024-05-18 15:19:40',NULL),(12,100075,32,5,'review','2024-05-18 15:19:40',NULL),(13,100075,33,5,'review','2024-05-18 15:19:40',NULL),(14,100092,34,5,'review','2024-05-18 15:21:40',NULL),(15,100092,35,5,'review','2024-05-18 15:21:40',NULL),(16,100092,36,5,'review','2024-05-18 15:21:40',NULL),(17,100092,37,4,'review','2024-05-18 15:21:40',NULL),(18,100036,38,5,'review','2024-05-18 15:24:45',NULL),(19,100036,39,5,'review','2024-05-18 15:24:45',NULL),(20,100036,40,5,'review','2024-05-18 15:24:45',NULL),(21,100036,41,4,'review','2024-05-18 15:24:45',NULL),(22,100036,42,5,'review','2024-05-18 15:24:45',NULL),(23,100140,43,5,'review','2024-05-18 15:26:58',NULL),(24,100140,44,4,'review','2024-05-18 15:26:58',NULL),(25,100140,45,5,'review','2024-05-18 15:26:58',NULL),(26,100140,46,4,'review','2024-05-18 15:26:58',NULL),(27,100140,47,5,'review','2024-05-18 15:26:58',NULL),(28,100140,48,5,'review','2024-05-18 15:26:58',NULL),(29,100140,49,5,'review','2024-05-18 15:26:58',NULL),(30,100102,50,5,'review','2024-05-18 15:28:22',NULL),(31,100102,51,4,'review','2024-05-18 15:28:22',NULL),(32,100102,52,5,'review','2024-05-18 15:28:22',NULL),(33,100102,53,4,'review','2024-05-18 15:28:22',NULL),(34,100123,56,5,'review','2024-05-18 15:30:37',NULL),(35,100123,57,4,'review','2024-05-18 15:30:37',NULL),(36,100123,58,5,'review','2024-05-18 15:30:37',NULL),(37,100123,59,5,'review','2024-05-18 15:30:37',NULL),(38,100123,60,5,'review','2024-05-18 15:30:37',NULL),(39,100076,61,5,'review','2024-05-18 15:32:36',NULL),(40,100076,62,5,'review','2024-05-18 15:32:36',NULL),(41,100076,63,5,'review','2024-05-18 15:32:36',NULL),(42,100076,64,5,'review','2024-05-18 15:32:36',NULL),(43,100077,66,4,'review','2024-05-18 15:34:28',NULL),(44,100077,67,4,'review','2024-05-18 15:34:29',NULL),(45,100077,68,4,'review','2024-05-18 15:34:29',NULL),(46,100077,69,5,'review','2024-05-18 15:34:29',NULL),(47,100077,70,5,'review','2024-05-18 15:34:29',NULL),(48,100042,71,5,'review','2024-05-18 15:36:27',NULL),(49,100042,72,4,'review','2024-05-18 15:36:27',NULL),(50,100042,73,3,'review','2024-05-18 15:36:27',NULL),(51,100042,74,5,'review','2024-05-18 15:36:27',NULL),(52,100021,76,5,'review','2024-05-18 15:57:34',NULL),(53,100021,77,5,'review','2024-05-18 15:57:34',NULL),(54,100021,78,4,'review','2024-05-18 15:57:34',NULL),(55,100021,79,5,'review','2024-05-18 15:57:34',NULL),(56,100021,80,4,'review','2024-05-18 15:57:34',NULL),(57,100021,81,4,'review','2024-05-18 15:57:34',NULL),(58,100069,82,5,'review','2024-05-18 15:59:02',NULL),(59,100069,83,4,'review','2024-05-18 15:59:02',NULL),(60,100069,84,5,'review','2024-05-18 15:59:02',NULL),(61,100037,85,5,'review','2024-05-18 16:00:35',NULL),(63,100037,87,4,'review','2024-05-18 16:00:36',NULL),(64,100362,88,4,'review','2024-05-18 16:05:22',NULL),(65,100362,89,5,'review','2024-05-18 16:05:22',NULL),(66,100362,90,5,'review','2024-05-18 16:05:22',NULL),(67,100362,91,5,'review','2024-05-18 16:05:22',NULL),(68,201342,92,4,'review','2024-05-18 16:06:47',NULL),(69,201342,93,5,'review','2024-05-18 16:06:47',NULL),(70,201342,94,4,'review','2024-05-18 16:06:47',NULL),(71,201342,95,5,'review','2024-05-18 16:06:47',NULL),(72,201342,96,5,'review','2024-05-18 16:06:47',NULL),(73,201342,97,4,'review','2024-05-18 16:06:47',NULL),(74,106836,98,5,'review','2024-05-18 16:08:36',NULL),(75,106836,99,5,'review','2024-05-18 16:08:36',NULL),(76,106836,100,5,'review','2024-05-18 16:08:36',NULL),(77,102327,101,4,'review','2024-05-18 16:10:22',NULL),(78,102327,102,5,'review','2024-05-18 16:10:22',NULL),(79,102327,103,5,'review','2024-05-18 16:10:22',NULL),(80,102327,104,4,'review','2024-05-18 16:10:22',NULL),(81,102327,105,5,'review','2024-05-18 16:10:22',NULL),(82,102327,106,4,'review','2024-05-18 16:10:22',NULL),(83,102327,107,5,'review','2024-05-18 16:10:22',NULL),(84,201341,108,5,'review','2024-05-18 16:11:20',NULL),(85,201344,110,4,'review','2024-05-18 16:13:43',NULL),(86,201344,111,5,'review','2024-05-18 16:13:43',NULL),(87,201344,112,5,'review','2024-05-18 16:13:43',NULL),(88,201344,113,5,'review','2024-05-18 16:13:43',NULL),(89,201340,114,5,'review','2024-05-18 16:14:58',NULL),(90,201340,115,5,'review','2024-05-18 16:14:58',NULL),(91,201340,116,4,'review','2024-05-18 16:14:58',NULL),(92,201344,117,5,'여기 진짜 경치도 좋고 공기도 좋고! 고기 먹을 맛이 나네요.. ?','2024-01-03 16:21:50','2024-05-18 16:21:50'),(93,201340,118,4,'여기 말 그대로 별빛존.. 별빛이 진짜 이뻐요.\n별들 보고 나서 사람들이랑 모여서 캠프파이어했는데 낭만 죽이네요','2024-05-18 16:26:14','2024-05-18 16:26:14'),(94,201343,120,5,'여기 진짜 경치도 좋고 공기도 좋고! 고기 먹을 맛이 나네요.. ?','2024-02-18 16:32:14','2024-05-18 16:32:14'),(95,201343,121,5,'호 카라반 캠핑장은 경기도 가평군 청평면에 위치해 있어, 서울에서 차로 약 1시간 30분 정도 소요되었습니다. 도착하니 주차 공간도 넉넉하고, 캠핑장 내부 도로가 잘 정비되어 있어 캠핑 장비를 옮기는 데 큰 불편함이 없었습니다.','2024-05-05 16:40:33','2024-05-18 16:40:33'),(96,201343,125,5,'캠핑장 주변에는 다양한 활동을 즐길 수 있었습니다. 가족과 함께 근처 산책로를 걸으며 자연을 만끽했고, 캠핑장 내에 있는 작은 연못에서 낚시도 즐겼습니다. 아이들은 캠핑장 내 놀이터에서 신나게 뛰어놀았습니다. 밤에는 별을 보며 캠프파이어를 즐겼는데, 정말 낭만적이었습니다.','2024-04-23 16:44:21','2024-05-18 16:44:21'),(97,201343,126,4,'애인이랑 다녀왔는데,, 음,, 괜찮네요.. 잘 정비된 시설과 다양한 활동, 그리고 아름다운 자연환경 덕분에 잊지 못할 추억을 만들 수 있었습니다. 다시 방문하고 싶은 캠핑장으로 강력히 추천합니다!','2024-01-01 16:52:01','2024-05-18 16:52:01');
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-20  9:51:28
