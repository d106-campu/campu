-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: k10d106.p.ssafy.io    Database: d106
-- ------------------------------------------------------
-- Server version	5.5.5-10.11.7-MariaDB-1:10.11.7+maria~ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `campsite_image`
--

DROP TABLE IF EXISTS `campsite_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `campsite_image` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '식별번호',
  `campsite_id` bigint(20) NOT NULL COMMENT '캠핑장 식별번호',
  `url` varchar(1024) NOT NULL COMMENT '이미지 주소',
  PRIMARY KEY (`id`),
  KEY `campsite_image_campsite_FK` (`campsite_id`),
  CONSTRAINT `campsite_image_campsite_FK` FOREIGN KEY (`campsite_id`) REFERENCES `campsite` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='캠핑장 이미지';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campsite_image`
--

LOCK TABLES `campsite_image` WRITE;
/*!40000 ALTER TABLE `campsite_image` DISABLE KEYS */;
INSERT INTO `campsite_image` VALUES (1,201343,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQLo5ocj2pBEgDoUiMF3Ax6X5hXlpMPUU42aw&s'),(2,201344,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTNQrJYrfJ9XAq7jGYSnBynQGkDPtTofgQZvA&s'),(3,201342,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQLo5ocj2pBEgDoUiMF3Ax6X5hXlpMPUU42aw&s'),(4,201340,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT7jT_p87s4Plg_3yETAJyW472dyUJl7M1zRQ&s'),(5,201344,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTGv4FGHXH-DQ7-iZKA_9E2Bh6dSe5VKby5Gg&s'),(6,201341,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR_za-oY7SRUgeTwlgDjU4quNPAxiMNevh9UQ&s'),(7,201340,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR2dQXhEll5m4m_53b-Z-0zbBAsT6SvFm0HMw&s'),(8,201340,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTV-X8NVuymjTrezSNtM12S59kqvjTSqIlCBw&s'),(9,201344,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTV-X8NVuymjTrezSNtM12S59kqvjTSqIlCBw&s'),(10,201340,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQLo5ocj2pBEgDoUiMF3Ax6X5hXlpMPUU42aw&s'),(11,201342,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR_za-oY7SRUgeTwlgDjU4quNPAxiMNevh9UQ&s'),(12,201343,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSuor1QrHmFB-uUs-dCMO4JbYOzrpMzseeTyw&s'),(13,201342,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTPCCaMZ5QmJ6sNdqFT8C3C2kYHaVxkQhlNsQ&s'),(14,201341,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRlFp3e7EU5YVX59C_uavxmZi3DyUngCgM-Cw&s'),(15,201341,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSTsUtLrPsoiKVPanX7XaY3TIpwaw9r0Vuyow&s'),(16,201340,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT7jT_p87s4Plg_3yETAJyW472dyUJl7M1zRQ&s'),(17,201342,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSuor1QrHmFB-uUs-dCMO4JbYOzrpMzseeTyw&s'),(18,201344,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTPCCaMZ5QmJ6sNdqFT8C3C2kYHaVxkQhlNsQ&s'),(19,201344,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTGv4FGHXH-DQ7-iZKA_9E2Bh6dSe5VKby5Gg&s'),(20,201341,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQLo5ocj2pBEgDoUiMF3Ax6X5hXlpMPUU42aw&s');
/*!40000 ALTER TABLE `campsite_image` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-20  9:51:24
