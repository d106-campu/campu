-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: k10d106.p.ssafy.io    Database: d106
-- ------------------------------------------------------
-- Server version	5.5.5-10.11.7-MariaDB-1:10.11.7+maria~ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `review_image`
--

DROP TABLE IF EXISTS `review_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_image` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '식별번호',
  `review_id` bigint(20) NOT NULL COMMENT '리뷰 식별번호',
  `url` varchar(1024) NOT NULL COMMENT '이미지 주소',
  PRIMARY KEY (`id`),
  KEY `review_image_review_FK` (`review_id`),
  CONSTRAINT `review_image_review_FK` FOREIGN KEY (`review_id`) REFERENCES `review` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='캠핑장 리뷰 이미지';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_image`
--

LOCK TABLES `review_image` WRITE;
/*!40000 ALTER TABLE `review_image` DISABLE KEYS */;
INSERT INTO `review_image` VALUES (1,92,'https://k10d106.p.ssafy.io/api/file/campsite/201344/review/117/21fbea5e-635a-4255-83df-467ee2890822_1.jpg'),(2,92,'https://k10d106.p.ssafy.io/api/file/campsite/201344/review/117/89af55ff-2fda-43be-8547-11517754b72b_2.jpg'),(3,93,'https://k10d106.p.ssafy.io/api/file/campsite/201340/review/118/1e8ce681-93a6-4037-ba48-63c15b086ed5_3.jpg'),(4,93,'https://k10d106.p.ssafy.io/api/file/campsite/201340/review/118/21cd30db-dec5-4cdf-8985-100ccd8c7578_4.jpg'),(5,93,'https://k10d106.p.ssafy.io/api/file/campsite/201340/review/118/69e44e0f-8dfd-47b0-bde1-a94629336b47_5.jpg'),(6,94,'https://k10d106.p.ssafy.io/api/file/campsite/201343/review/120/229638eb-6c1f-4d08-9759-1bb43a41a9be_6.jpg'),(7,94,'https://k10d106.p.ssafy.io/api/file/campsite/201343/review/120/04f76e3b-35b0-462f-a4e4-76cece7274b0_5.jpg'),(8,95,'https://k10d106.p.ssafy.io/api/file/campsite/201343/review/121/f352a515-4966-46d7-9aae-6c7f1ace577e_1.jpg'),(9,95,'https://k10d106.p.ssafy.io/api/file/campsite/201343/review/121/9e176006-ac0b-4f7e-b759-3aa36148620e_2.jpg'),(10,95,'https://k10d106.p.ssafy.io/api/file/campsite/201343/review/121/d4da3185-4c35-4793-b3be-eb2513a7955a_3.jpg'),(11,96,'https://k10d106.p.ssafy.io/api/file/campsite/201343/review/125/e7a17d3c-2dea-4619-be5a-4e374b10e072_2.jpg'),(12,97,'https://k10d106.p.ssafy.io/api/file/campsite/201343/review/126/3ce6a482-321a-466f-af4d-a290cfb83247_1.jpg'),(13,97,'https://k10d106.p.ssafy.io/api/file/campsite/201343/review/126/566aaf58-7b4e-4f28-aa45-589ae8c4e89d_2.jpg'),(14,97,'https://k10d106.p.ssafy.io/api/file/campsite/201343/review/126/3ed4de04-4ba8-4a6d-8b0a-bd63dbdb0edd_3.jpg');
/*!40000 ALTER TABLE `review_image` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-20  9:51:23
