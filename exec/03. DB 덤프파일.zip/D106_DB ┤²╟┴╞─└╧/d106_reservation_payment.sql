-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: k10d106.p.ssafy.io    Database: d106
-- ------------------------------------------------------
-- Server version	5.5.5-10.11.7-MariaDB-1:10.11.7+maria~ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `reservation_payment`
--

DROP TABLE IF EXISTS `reservation_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservation_payment` (
  `reservation_id` bigint(20) NOT NULL COMMENT '예약 식별번호',
  `imp_uid` varchar(256) DEFAULT NULL COMMENT '결제 고유번호',
  `pg` varchar(64) DEFAULT NULL COMMENT 'PG사 코드 및 상점 ID',
  `pay_method` varchar(32) DEFAULT NULL COMMENT '결제 방법',
  `merchant_uid` varchar(256) DEFAULT NULL COMMENT '주문 고유번호',
  `name` varchar(256) DEFAULT NULL COMMENT '상품명',
  `amount` bigint(20) DEFAULT NULL COMMENT '가격',
  `buyer_email` varchar(128) DEFAULT NULL COMMENT '구매자 이메일',
  `buyer_name` varchar(32) DEFAULT NULL,
  `buyer_tel` varchar(16) DEFAULT NULL COMMENT '구매자 전화번호',
  `buyer_addr` varchar(256) DEFAULT NULL COMMENT '구매자 주소',
  `buyer_postcode` varchar(16) DEFAULT NULL COMMENT '구매자 우편번호',
  KEY `payment_reservation_FK` (`reservation_id`),
  CONSTRAINT `payment_reservation_FK` FOREIGN KEY (`reservation_id`) REFERENCES `reservation` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='결제';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation_payment`
--

LOCK TABLES `reservation_payment` WRITE;
/*!40000 ALTER TABLE `reservation_payment` DISABLE KEYS */;
INSERT INTO `reservation_payment` VALUES (65,'imp_762941021499','kakaopay.TC0ONETIME','card','20240518-315c1e42-0846-4e90-8c2f-b853ff11871b','호 카라반 캠핑-글램핑1',460000,'unknown','시연','01088737660','unknown','unknown'),(75,'imp_800574547997','kakaopay.TC0ONETIME','card','20240518-6f7691b7-fcf0-4950-9ede-4b8d7faddff5','호 카라반 캠핑-글램핑1',220000,'unknown','refo','00000000000','unknown','unknown'),(122,NULL,'kakaopay.TC0ONETIME','card','20240518-e9ae901c-6f45-4f30-a73d-4d832016861e','호 카라반 캠핑-글램핑1',60000,'unknown','refo','00000000000','unknown','unknown'),(123,NULL,'kakaopay.TC0ONETIME','card','20240518-393ba3d8-9a70-4cd9-88f8-bedfd1a9bbe7','호 카라반 캠핑-글램핑1',60000,'unknown','refo','00000000000','unknown','unknown'),(124,'imp_655114663830','kakaopay.TC0ONETIME','card','20240518-7800cb06-937c-4f4d-b595-43151be5c94a','호 카라반 캠핑-글램핑1',460000,'unknown','refo','00000000000','unknown','unknown'),(127,'imp_857736947821','kakaopay.TC0ONETIME','card','20240518-c68019c7-a43d-4711-8d75-95b9e9464a35','호 카라반 캠핑-글램핑1',460000,'unknown','시연','01029775868','unknown','unknown'),(128,'imp_510597506289','kakaopay.TC0ONETIME','card','20240518-d7391afc-506a-4658-88a3-516b6a56a2b8','호 카라반 캠핑-글램핑1',460000,'unknown','불꽃두목주용','00000000000','unknown','unknown'),(129,'imp_910683517965','kakaopay.TC0ONETIME','card','20240518-75b3d360-be6e-4f69-a061-51b34fdac136','호 카라반 캠핑-글램핑1',460000,'unknown','불꽃두목주용','00000000000','unknown','unknown'),(130,'imp_549911420843','kakaopay.TC0ONETIME','card','20240518-f0d0b6fc-8c02-4238-91c3-7536668e5998','호 카라반 캠핑-글램핑1',460000,'unknown','불꽃두목주용','00000000000','unknown','unknown'),(131,NULL,'kakaopay.TC0ONETIME','card','20240518-a0e9ff66-5a81-4f1a-b988-fabd2d151f02','호 카라반 캠핑-글램핑1',140000,'unknown','불꽃두목주용','00000000000','unknown','unknown'),(132,'imp_303790857042','kakaopay.TC0ONETIME','card','20240518-9d518856-1c1f-4710-8439-d46eb54a9b31','호 카라반 캠핑-글램핑1',140000,'unknown','불꽃두목주용','00000000000','unknown','unknown'),(133,NULL,'kakaopay.TC0ONETIME','card','20240518-c3ba97c3-51d8-45bb-b56b-a42adc729888','호 카라반 캠핑-글램핑1',140000,'unknown','불꽃두목주용','00000000000','unknown','unknown'),(134,'imp_901592738179','kakaopay.TC0ONETIME','card','20240518-5348c14a-f8f4-4f0c-992c-364b724bc1ea','호 카라반 캠핑-글램핑1',140000,'unknown','불꽃두목주용','00000000000','unknown','unknown'),(135,'imp_970561047490','kakaopay.TC0ONETIME','card','20240518-82047946-8881-4a09-81da-020e9f806179','싸피 글램핑-오토캠핑1',400000,'unknown','test계정1','00000000005','unknown','unknown'),(136,'imp_889238059675','kakaopay.TC0ONETIME','card','20240518-c469c6eb-2e50-49a5-a43d-cbb60f432b78','호 카라반 캠핑-글램핑1',140000,'unknown','불꽃두목주용','00000000000','unknown','unknown'),(137,'imp_121280549652','kakaopay.TC0ONETIME','card','20240518-dcc5dce6-ddcb-48da-8876-016ef431e5f1','흑석산 자연 휴양림-자동차야영장1',80000,'unknown','준호짱맨','00000000000','unknown','unknown'),(138,'imp_083707842943','kakaopay.TC0ONETIME','card','20240518-a1d706e5-353d-46bb-b356-f158ad3438d0','가마실캠핑장-카라반1',190000,'unknown','최사장','00000000000','unknown','unknown'),(139,'imp_872725042806','kakaopay.TC0ONETIME','card','20240518-fe6de876-debb-4e6e-8b90-2dbf1f640e40','호 카라반 캠핑-글램핑1',140000,'unknown','불꽃두목주용','00000000000','unknown','unknown'),(140,'imp_179970111150','kakaopay.TC0ONETIME','card','20240518-eec695ed-c108-4574-a804-63bdb5d52779','The Star 오토캠핑장-글램핑1',290000,'unknown','최사장','00000000000','unknown','unknown'),(141,'imp_330098880842','kakaopay.TC0ONETIME','card','20240518-a08ea178-2657-4355-9b88-3daae3803ee4','호 카라반 캠핑-글램핑1',140000,'unknown','불꽃두목주용','00000000000','unknown','unknown'),(142,'imp_476317721610','kakaopay.TC0ONETIME','card','20240518-f62e5b31-fd89-4660-827c-1e56211732ad','가마실캠핑장-카라반1',190000,'unknown','choihojo','00000000000','unknown','unknown'),(143,'imp_456493331636','kakaopay.TC0ONETIME','card','20240518-50e71fa8-0471-4468-a951-dacd3843c382','흑석산 자연 휴양림-자동차야영장1',160000,'unknown','최사장','00000000000','unknown','unknown'),(145,'imp_862712210813','kakaopay.TC0ONETIME','card','20240518-ce818857-83cc-4d32-bf7e-ddceb8c775f6','청계산 골든밸리 가족캠핑장-글램핑1',270000,'unknown','최사장','00000000000','unknown','unknown'),(146,'imp_748369842200','kakaopay.TC0ONETIME','card','20240518-ece10620-42ef-490f-95f9-63ecd35f4d62','The Star 오토캠핑장-글램핑1',290000,'unknown','최사장','00000000000','unknown','unknown'),(147,'imp_235645816346','kakaopay.TC0ONETIME','card','20240519-dd15d07f-6e81-42dc-b376-13c2fa549a82','청계산 골든밸리 가족캠핑장-글램핑1',270000,'unknown','최사장','00000000000','unknown','unknown'),(148,'imp_359060254313','kakaopay.TC0ONETIME','card','20240519-179563df-7acb-4036-926c-6f89bff7f92b','Camp 1950-글램핑1',280000,'unknown','최사장','00000000000','unknown','unknown'),(149,'imp_301407206408','kakaopay.TC0ONETIME','card','20240519-10b3f75a-1b3a-496b-9fba-1802e6431161','청계산 골든밸리 가족캠핑장-글램핑1',270000,'unknown','test계정1','00000000005','unknown','unknown'),(150,'imp_644254405562','kakaopay.TC0ONETIME','card','20240519-ebfa5255-f061-413b-b489-cf7e4b0df352','호 카라반 캠핑-글램핑1',140000,'unknown','불꽃두목주용','00000000000','unknown','unknown'),(151,'imp_557416484745','kakaopay.TC0ONETIME','card','20240519-835da17c-1a61-493d-bfa2-fb63dbc48e48','호 카라반 캠핑-글램핑1',140000,'unknown','불꽃두목주용','00000000000','unknown','unknown'),(152,'imp_441582056882','kakaopay.TC0ONETIME','card','20240519-6a87a99c-e60a-4dca-b0d7-e0abac4e7aa3','호 카라반 캠핑-글램핑1',460000,'unknown','시연','01029775868','unknown','unknown'),(153,'imp_560295669551','kakaopay.TC0ONETIME','card','20240519-4347a924-f07a-4145-8d97-e35ec9838917','청계산 골든밸리 가족캠핑장-글램핑1',170000,'unknown','단비꺼야아아','01085133964','unknown','unknown'),(154,'imp_409624819748','kakaopay.TC0ONETIME','card','20240519-8fabb577-5a67-4fbc-8582-e29cabe458e7','바다로글램핑-카라반1',110000,'unknown','단비꺼야아아','01085133964','unknown','unknown'),(155,'imp_170337121463','kakaopay.TC0ONETIME','card','20240519-1b583cc7-c44b-4f0d-8028-db67454c41e7','가평 사과나무 캠핑장-자동차야영장1',280000,'unknown','단비꺼야아아','01085133964','unknown','unknown'),(156,'imp_002405188894','kakaopay.TC0ONETIME','card','20240519-70a76c5b-a802-48a5-9b45-d0dcef365cad','CLUB 596-자동차야영장1',300000,'unknown','단비꺼야아아','01085133964','unknown','unknown'),(157,NULL,'kakaopay.TC0ONETIME','card','20240519-ddec775d-1256-4488-9d73-484e96e5ef48','함허동천야영장-일반야영장1',240000,'unknown','단비꺼야아아','01085133964','unknown','unknown'),(158,'imp_446429591460','kakaopay.TC0ONETIME','card','20240519-486b76b3-3ba8-4803-947c-9fcb6d15c3cc','함허동천야영장-일반야영장1',240000,'unknown','단비꺼야아아','01085133964','unknown','unknown'),(159,'imp_717643585182','kakaopay.TC0ONETIME','card','20240519-0bd9a41d-c4b4-4ed6-acdf-f1158dae09cf','가래골농원 캠핑장-글램핑1',210000,'unknown','단비꺼야아아','01085133964','unknown','unknown'),(160,NULL,'kakaopay.TC0ONETIME','card','20240519-f625f9e1-8c23-4c46-9f64-e56e3339446d','호 카라반 캠핑-글램핑1',140000,'unknown','불꽃두목주용','00000000000','unknown','unknown'),(161,'imp_734725135829','kakaopay.TC0ONETIME','card','20240519-57fd7a72-3eb9-419c-9227-d227715e478f','호 카라반 캠핑-글램핑1',460000,'unknown','불꽃두목주용','00000000000','unknown','unknown'),(162,'imp_057985731963','kakaopay.TC0ONETIME','card','20240519-874fca74-a3ab-4e3b-a279-faf700ff1d5b','호 카라반 캠핑-글램핑1',460000,'unknown','불꽃두목주용','00000000000','unknown','unknown'),(163,'imp_375114747257','kakaopay.TC0ONETIME','card','20240519-7c5db5e2-838f-47b1-b4d0-c85cc20e375c','호 카라반 캠핑-글램핑1',460000,'unknown','시연','01029775868','unknown','unknown'),(164,'imp_767498210335','kakaopay.TC0ONETIME','card','20240519-9e5b9e3f-6c72-4e20-a229-e2e31626ab8e','호 카라반 캠핑-글램핑2',460000,'unknown','불꽃두목주용','00000000000','unknown','unknown'),(165,'imp_996991684723','kakaopay.TC0ONETIME','card','20240519-7021bb72-ab86-4354-bae1-ce154f1a8160','호 카라반 캠핑-글램핑1',460000,'unknown','시연','01029775868','unknown','unknown');
/*!40000 ALTER TABLE `reservation_payment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-20  9:51:29
