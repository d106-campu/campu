-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: k10d106.p.ssafy.io    Database: d106
-- ------------------------------------------------------
-- Server version	5.5.5-10.11.7-MariaDB-1:10.11.7+maria~ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `empty_notification`
--

DROP TABLE IF EXISTS `empty_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empty_notification` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '식별번호',
  `user_id` bigint(20) NOT NULL COMMENT '회원 식별번호',
  `room_id` bigint(20) NOT NULL COMMENT '방 식별번호',
  `start_date` date DEFAULT NULL COMMENT '숙박 시작날짜',
  `end_date` date DEFAULT NULL COMMENT '숙박 종료날짜',
  `create_time` datetime DEFAULT current_timestamp() COMMENT '생성 시간',
  `update_time` datetime DEFAULT NULL COMMENT '수정 시간',
  PRIMARY KEY (`id`),
  KEY `empty_notification_user_FK` (`user_id`),
  KEY `empty_notification_room_FK` (`room_id`),
  CONSTRAINT `empty_notification_room_FK` FOREIGN KEY (`room_id`) REFERENCES `room` (`id`),
  CONSTRAINT `empty_notification_user_FK` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='빈자리 알림';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empty_notification`
--

LOCK TABLES `empty_notification` WRITE;
/*!40000 ALTER TABLE `empty_notification` DISABLE KEYS */;
INSERT INTO `empty_notification` VALUES (16,11,1012021,'2024-05-19','2024-05-20','2024-05-19 01:27:41','2024-05-19 01:27:41'),(18,11,1000371,'2024-05-25','2024-05-26','2024-05-19 02:47:13','2024-05-19 02:47:13'),(19,11,1034361,'2024-05-19','2024-05-20','2024-05-19 03:21:41','2024-05-19 03:21:41'),(23,10,2013406,'2024-05-20','2024-05-21','2024-05-19 23:58:01','2024-05-19 23:58:01'),(25,11,2013406,'2024-05-20','2024-05-22','2024-05-20 09:29:18','2024-05-20 09:29:18');
/*!40000 ALTER TABLE `empty_notification` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-20  9:51:26
